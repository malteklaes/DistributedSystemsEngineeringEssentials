package server;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import io.grpc.Grpc;
import io.grpc.InsecureServerCredentials;
import io.grpc.ServerBuilder;
import io.grpc.chatService.ChatServiceGrpc;
import io.grpc.chatService.ChatServiceOuterClass.ChatMsg;
import io.grpc.stub.StreamObserver;
import util.CipherService;
import util.Colors;
import util.EPatternStrategy;
import util.InteractionUtilService;
import util.TimeStampService;

/**
 * service was build based on two sources:
 * 
 * [1] https://grpc.io/docs/languages/java/basics/
 * 
 * [2]
 * https://github.com/grpc/grpc-java/blob/master/examples/src/main/java/io/grpc/examples/routeguide/RouteGuideServer.java
 * 
 * [3]
 * http://grpc.github.io/grpc-java/javadoc/io/grpc/ServerBuilder.html#addServices(java.util.List)
 * 
 * class also build on automated generated classes based on gRPC
 * 
 * @author Malte
 *
 */
public class ServerChatService {

	private final static int port = InteractionUtilService.CHATSERVICE_PORT;
	private io.grpc.Server server;
	private final ExecutorService executorService;

	private EPatternStrategy patternStrattegy;

	/**
	 * Create a ServerChatService server listening on {@code port} using
	 * {@code featureFile} database.
	 * 
	 * based on source [1][2]
	 * 
	 * @param patternStrattegy
	 * @throws IOException
	 */
	public ServerChatService(EPatternStrategy patternStrattegy) throws IOException {
		this(Grpc.newServerBuilderForPort(port, InsecureServerCredentials.create()), patternStrattegy);
	}

	/**
	 * Create a ServerChatService server using serverBuilder as a base and features
	 * as data. Switch between two strategies/patterns:
	 * 
	 * (1) STATIC_INSTANCE
	 * 
	 * (2) PER_REQUEST_INSTANCE_AND_POOLING (with gRPC-executor in the background)
	 * 
	 * based on source [1][2][3]
	 * 
	 * @param serverBuilder
	 * @param patternStrattegy
	 */
	private ServerChatService(ServerBuilder<?> serverBuilder, EPatternStrategy patternStrattegy) {
		this.patternStrattegy = patternStrattegy;
		this.executorService = Executors.newFixedThreadPool(Server.POOLSIZE);

		switch (this.patternStrattegy) {
		case STATIC_INSTANCE:
			server = serverBuilder.addService(new ServerChatServiceServant()).build();
			try {
				this.start();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;
		case PER_REQUEST_INSTANCE_AND_POOLING:
			this.server = ServerBuilder.forPort(port).addService(new ServerChatServiceServant())
					.executor(executorService).build();
			try {
				this.start();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;
		default:
			System.err.print("No strategy was chosen beforehand!");
			break;

		}

	}

	/**
	 * Start serving requests.
	 * 
	 * based on source [1][2]
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void start() throws IOException, InterruptedException {
		server.start();
		System.out.println("[Server]  was initilized with strategy/pattern: " + this.patternStrattegy);
		System.out.println("[Server] is running on port: " + port);
		this.blockUntilShutdown();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				System.out.println("...............runns ......................");
				System.err.println("*** shutting down gRPC server since JVM is shutting down");
				try {
					ServerChatService.this.stop();
				} catch (InterruptedException e) {
					e.printStackTrace(System.err);
				}
				System.err.println("*** server shut down");
			}
		});
	}

	/**
	 * Stop serving requests and shutdown resources.
	 * 
	 * based on source [1][2]
	 */
	private void stop() throws InterruptedException {
		if (server != null) {
			server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
		}
	}

	/**
	 * Await termination on the main thread since the grpc library uses daemon
	 * threads.
	 * 
	 * based on source [1][2]
	 */
	private void blockUntilShutdown() throws InterruptedException {
		if (server != null) {
			server.awaitTermination();
		}
	}

	/**
	 * just for creating servants for a new client
	 * 
	 * based on source [1][2]
	 * 
	 * @author Malte
	 *
	 */
	private class ServerChatServiceServant extends ChatServiceGrpc.ChatServiceImplBase {

		@Override
		synchronized public void sendMsg(ChatMsg chatMsg, StreamObserver<ChatMsg> responseObserver) {
			String threadName = Thread.currentThread().getName();
			int servantID = this.getThreadIDFromThreadPool(threadName);

			String serverGreetingEncrypted = CipherService
					.msgEncryption("Greetings from ChatServer_Servant-" + servantID + ": ");

			ChatMsg chatMsgReply = ChatMsg.newBuilder().setContent(chatMsg.getContent()).build();
			String responseEncryptedString = serverGreetingEncrypted + this.encryptMsg(chatMsg.getContent());
			ChatMsg response = ChatMsg.newBuilder().setContent(responseEncryptedString).build();
			printMsgExchange(servantID, chatMsgReply.getContent(), response.getContent());
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		/**
		 * prints actual server-side-processing to console
		 * 
		 * @param servantID
		 * @param encMsg
		 * @param decReply
		 */
		synchronized private void printMsgExchange(int servantID, String encMsg, String decReply) {
			String threadcontext = Thread.currentThread().getName();
			System.out.println("=================");
			System.out.println("Thread-context: [" + threadcontext + "] handling request in server");
			System.out.println(Colors.printHighlighted(Colors.RED,
					"[Servant-" + servantID + "] original message (client-request): " + encMsg));
			System.out.println(Colors.printHighlighted(Colors.GREEN, "[Servant-" + servantID
					+ "]  decrypted message (client-request): " + CipherService.msgDecryption(encMsg)));
			System.out.println("[Servant-" + servantID + "]  decrypted message (server-reply): " + decReply);
			System.out.println(TimeStampService.chronNow());
			System.out.println("=================");
		}

		private String encryptMsg(String notProcessedStringPart) {
			return CipherService.msgEncryption(" (your msg was: ") + notProcessedStringPart
					+ CipherService.msgEncryption(")");
		}

		/**
		 * return the number of the thread in its threadPool/threadPoolContext: e.g.
		 * "47" for "pool-2-thread-47"
		 * 
		 * @param threadName (not null or empty)
		 * @return int (threadID)
		 */
		private int getThreadIDFromThreadPool(String threadName) {
			assert threadName != null || threadName.length() > 0 : "threadName is null or empty!";
			int lastIndex = threadName.lastIndexOf('-');
			int threadID = Integer.parseInt(threadName.substring(lastIndex + 1));
			return threadID;
		}
	}

}
