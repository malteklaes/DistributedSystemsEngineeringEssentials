package util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class InteractionUtilService {

	public final static EPatternStrategy REMOTING_LIFECYCLE_MGMT = EPatternStrategy.PER_REQUEST_INSTANCE_AND_POOLING; // STATIC_INSTANCE
	// //
	// PER_REQUEST_INSTANCE_AND_POOLING

	// find in cmd: (netstat -aon | find /i "50051")
	public final static int CHATSERVICE_PORT = 50051;

	public final static List<String> VOCABULARY = new ArrayList<>(Arrays.asList("Hello", "Good Morning", "Hi", "Hola",
			"Bonjour", "Guten Tag", "Ciao", "Salut", "Namaste", "Shalom", "Kon'nichiwa", "Annyeonghaseyo", "Salam",
			"Merhaba", "Hallo", "Sawasdee", "Jambo", "Privet", "Hej", "Selamat pagi"));

	public static String getRandomGreetingfromVocabulary() {
		if (VOCABULARY.isEmpty()) {
			return "No greetings available.";
		}

		Random random = new Random();
		int randomIndex = random.nextInt(VOCABULARY.size());
		return VOCABULARY.get(randomIndex);
	}

}
