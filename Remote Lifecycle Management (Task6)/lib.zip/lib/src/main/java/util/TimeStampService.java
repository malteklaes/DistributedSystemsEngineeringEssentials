package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeStampService {

	/**
	 * Sets up a time-representation with date and time like: (dd-MM-yyyy
	 * HH:mm:ss:SS:AA)
	 *
	 * @return String (time, not null)
	 */
	public static String chronNow() {
		LocalDateTime chronObj = LocalDateTime.now();
		DateTimeFormatter chronFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss:SS:AA");
		return Colors.printHighlighted(Colors.YELLOW, "[" + chronObj.format(chronFormatObj) + "]");
	}

}
