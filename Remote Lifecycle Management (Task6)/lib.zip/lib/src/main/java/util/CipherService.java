package util;

import rot13.src.main.java.org.soulwing.rot13.Rot13;

/**
 * simple encryption service which works with rot13
 * (https://github.com/soulwing/rot13)
 * 
 * @author Malte
 *
 */
public class CipherService extends Rot13 {

	private String unEncrpytedMsg;
	private String enrpytedMsg;
	private int slowDownTime = 1000; // seconds

	// constructor should take long time
	public CipherService() {
		unEncrpytedMsg = "";
		enrpytedMsg = "";
		timePause();
	}

	/**
	 * assumes clear-text-msg, which is not yet encrypted
	 * 
	 * @param msg
	 * @return String
	 */
	public static String msgEncryption(String msg) {
		assert msg != null || msg.length() != 0 : "msg was null or empty";
		return Rot13.rotate(msg);
	}

	/**
	 * assumes encMsg is Rot13-encrpyted
	 * 
	 * @param encMsg (Rot13-encrpyted string)
	 * @return String
	 */
	public static String msgDecryption(String encMsg) {
		assert encMsg != null || encMsg.length() != 0 : "encMsg was null or empty";
		return Rot13.rotate(encMsg);
	}

	private void timePause() {
		try {
			Thread.sleep(slowDownTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
