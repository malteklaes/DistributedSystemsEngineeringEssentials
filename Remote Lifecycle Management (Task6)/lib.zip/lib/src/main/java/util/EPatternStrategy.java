package util;

public enum EPatternStrategy {
	STATIC_INSTANCE, PER_REQUEST_INSTANCE_AND_POOLING;
}
