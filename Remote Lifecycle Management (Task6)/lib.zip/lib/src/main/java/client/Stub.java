package client;

import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.ManagedChannel;
import io.grpc.chatService.ChatServiceGrpc;
import io.grpc.chatService.ChatServiceOuterClass.ChatMsg;
import util.CipherService;
import util.Colors;
import util.TimeStampService;

/**
 * service was build based on two sources:
 * 
 * [1] https://grpc.io/docs/languages/java/basics/
 * 
 * [2]
 * https://github.com/grpc/grpc-java/blob/master/examples/src/main/java/io/grpc/examples/routeguide/RouteGuideClient.java
 * 
 * class also build on automated generated classes based on gRPC
 * 
 * @author Malte
 *
 */
public class Stub {

	private ChatServiceGrpc.ChatServiceBlockingStub blockingStub;

	private final String address;
	private final String target;

	/**
	 * based on source [1][2]
	 * 
	 * @param port
	 */
	public Stub(int port) {
		this.address = "localhost:";
		this.target = address + port; // "localhost:50051"
		this.initializeStub();
	}

	/**
	 * iniliazed blockingStub
	 * 
	 * based on source [1][2]
	 */
	private void initializeStub() {
		System.out.println("[Client]-stub initialize...");
		ManagedChannel channel = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
		try {
			blockingStub = ChatServiceGrpc.newBlockingStub(channel);
			System.out.println("[Client] running on port/address: " + target);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * first encrypts plain text msg and sends it to server
	 * 
	 * based on source [1][2]
	 * 
	 * @param plainTextMsg (not null)
	 */
	public void sendEncrpytedMsg(String plainTextMsg) {
		assert plainTextMsg != null : "Plaintextmsg was null";
		String encryptedMsg = CipherService.msgEncryption(plainTextMsg);
		ChatMsg chatMsgEncrpyted = ChatMsg.newBuilder().setContent(encryptedMsg).build();
		ChatMsg response = blockingStub.sendMsg(chatMsgEncrpyted); // here actual method call
		synchronized (this) {
			System.out.println("=================");
			System.out.println("[Client] Plain-text-msg to server is: " + plainTextMsg);
			System.out.println(Colors.printHighlighted(Colors.RED,
					"[Client] Encrypted-response from server: " + response.getContent()));
			this.printDecrpytedMsg(response);
			System.out.println("=================");
		}
	}

	private void printDecrpytedMsg(ChatMsg encryptedServerResponse) {
		System.out.println(Colors.printHighlighted(Colors.GREEN, "[Client] Decrypted-response from server: "
				+ CipherService.msgDecryption(encryptedServerResponse.getContent())));
		System.out.println(TimeStampService.chronNow());
	}

}
