package server;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import util.Colors;
import util.EPatternStrategy;
import util.InteractionUtilService;

public class Server {

	protected static final int POOLSIZE = 50;
	public static final ExecutorService THREADPOOL = Executors.newFixedThreadPool(POOLSIZE);

	public static void main(String[] args) {
		System.out.println(Colors.printHighlighted(Colors.CYAN_BOLD_BRIGHT,
				"This strategy in server: " + InteractionUtilService.REMOTING_LIFECYCLE_MGMT));

		switch (InteractionUtilService.REMOTING_LIFECYCLE_MGMT) {
		case STATIC_INSTANCE:
			new Thread(singleInstanceStrategy()).start();
			break;
		case PER_REQUEST_INSTANCE_AND_POOLING:
			new Thread(perRequestInstanceAndPoolingStrategy()).start();
			break;
		default:
			System.out.println("No strategy was chosen in client!");
			break;
		}

	}

	private static Runnable singleInstanceStrategy() {
		Runnable msgTask = () -> {
			try {
				new ServerChatService(EPatternStrategy.STATIC_INSTANCE);
			} catch (IOException e) {
				e.printStackTrace();
			}
		};
		return msgTask;
	}

	private static Runnable perRequestInstanceAndPoolingStrategy() {
		Runnable msgTask = () -> {
			try {
				new ServerChatService(EPatternStrategy.PER_REQUEST_INSTANCE_AND_POOLING);
			} catch (IOException e) {
				e.printStackTrace();
			}
		};
		return msgTask;
	}

}
