package client;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import util.Colors;
import util.InteractionUtilService;

public class Client {

	public static final int CLIENT_UPTIME = 10; // [seconds]

	private static final int numberOfClients = 50;
	private static final int fixedNumberOfRemoteObjects = 3;
	public static final ExecutorService THREADPOOL = Executors.newFixedThreadPool(2);

	private static Stub singleInstanceClientStub;

	public static void main(String[] args) {

		System.out.println(Colors.printHighlighted(Colors.CYAN_BOLD_BRIGHT,
				"This strategy in client: " + InteractionUtilService.REMOTING_LIFECYCLE_MGMT));
		switch (InteractionUtilService.REMOTING_LIFECYCLE_MGMT) {
		case STATIC_INSTANCE:
			singleInstanceStrategy();
			break;
		case PER_REQUEST_INSTANCE_AND_POOLING:
			perRequestInstanceAndPoolingStrategy();
			break;
		default:
			System.out.println("No strategy was chosen in client!");
			break;
		}

	}

	private static void singleInstanceStrategy() {
		for (int i = 0; i < fixedNumberOfRemoteObjects; i++) {
			singleInstanceClientStub = new Stub(InteractionUtilService.CHATSERVICE_PORT);
			singleInstanceClientStub.sendEncrpytedMsg(InteractionUtilService.getRandomGreetingfromVocabulary());
		}
		try {
			terminateThreadPool();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private static void perRequestInstanceAndPoolingStrategy() {
		for (int i = 0; i < numberOfClients; i++) {
			THREADPOOL.submit(initTask());
		}
		try {
			terminateThreadPool();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private static Runnable initTask() {
		Runnable msgTask = () -> {
			sendMsgTask(InteractionUtilService.CHATSERVICE_PORT);
		};
		return msgTask;
	}

	private static void sendMsgTask(int port) {
		Stub clientStub = null;
		clientStub = new Stub(port);
		clientStub.sendEncrpytedMsg(InteractionUtilService.getRandomGreetingfromVocabulary());

	}

	private static void terminateThreadPool() throws InterruptedException {
		if (!THREADPOOL.awaitTermination(CLIENT_UPTIME, TimeUnit.SECONDS)) {
			THREADPOOL.shutdown();
			System.out.println("\n...clients threadpool is terminated...");
		}
	}

}
